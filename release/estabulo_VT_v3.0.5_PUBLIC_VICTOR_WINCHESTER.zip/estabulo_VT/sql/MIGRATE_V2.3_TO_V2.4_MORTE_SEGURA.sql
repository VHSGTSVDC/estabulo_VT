-- estabulo_VT v2.4.0 — morte e recuperação segura
ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `critical_until` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `death_confirmations` INT NOT NULL DEFAULT 0;

-- Limpa estados transitórios antigos, sem ressuscitar cavalos já falecidos.
UPDATE `lrrp_horses`
SET `death_confirmations`=0
WHERE `death_confirmations` IS NULL;
