ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `rarity` VARCHAR(16) NOT NULL DEFAULT 'common',
  ADD COLUMN IF NOT EXISTS `mutation` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `insurance_until` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `death_state` VARCHAR(16) NOT NULL DEFAULT 'alive',
  ADD COLUMN IF NOT EXISTS `ranch_id` INT NULL;

UPDATE `lrrp_horses` SET `mutation`='{}' WHERE `mutation` IS NULL;

CREATE TABLE IF NOT EXISTS `lrrp_ranches` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `level` INT NOT NULL DEFAULT 1,
  `capacity` INT NOT NULL DEFAULT 10,
  `x` DOUBLE NOT NULL, `y` DOUBLE NOT NULL, `z` DOUBLE NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_ranch_owner` (`identifier`,`charidentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_pregnancies` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL,
  `mother_id` INT NOT NULL,
  `father_id` INT NOT NULL,
  `foal_name` VARCHAR(32) NOT NULL,
  `started_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `finish_at` DATETIME NOT NULL,
  `status` VARCHAR(16) NOT NULL DEFAULT 'pregnant',
  PRIMARY KEY (`id`), KEY `idx_preg_due` (`status`,`finish_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_auctions` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `horse_id` INT NOT NULL,
  `seller_identifier` VARCHAR(80) NOT NULL,
  `seller_charidentifier` INT NOT NULL,
  `start_price` INT NOT NULL,
  `currency` TINYINT NOT NULL DEFAULT 0,
  `current_bid` INT NOT NULL DEFAULT 0,
  `bidder_identifier` VARCHAR(80) NULL,
  `bidder_charidentifier` INT NULL,
  `ends_at` DATETIME NOT NULL,
  `status` VARCHAR(16) NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_auction_horse_status` (`horse_id`,`status`), KEY `idx_auction_due` (`status`,`ends_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_championship_points` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `season` VARCHAR(64) NOT NULL,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL,
  `horse_id` INT NOT NULL,
  `points` INT NOT NULL DEFAULT 0,
  `wins` INT NOT NULL DEFAULT 0,
  `races` INT NOT NULL DEFAULT 0,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_season_horse` (`season`,`horse_id`), KEY `idx_champ_rank` (`season`,`points`,`wins`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_seasons` (
  `season` VARCHAR(64) NOT NULL,
  `finalized_at` DATETIME NULL,
  PRIMARY KEY (`season`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
