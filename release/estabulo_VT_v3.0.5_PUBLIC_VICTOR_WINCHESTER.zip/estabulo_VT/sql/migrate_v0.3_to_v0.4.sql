-- Execute este arquivo somente ao atualizar da v0.3.x para a v0.4.x.
ALTER TABLE `lrrp_horses`
  ADD COLUMN `purchase_currency` TINYINT NOT NULL DEFAULT 0 AFTER `price`;

CREATE TABLE IF NOT EXISTS `lrrp_stable_accessories` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(64) NOT NULL,
  `charidentifier` INT NOT NULL,
  `category` VARCHAR(32) NOT NULL,
  `component_hash` VARCHAR(24) NOT NULL,
  `price_paid` INT NOT NULL DEFAULT 0,
  `currency` TINYINT NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_owned_accessory` (`identifier`,`charidentifier`,`category`,`component_hash`),
  KEY `idx_accessory_owner` (`identifier`,`charidentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
