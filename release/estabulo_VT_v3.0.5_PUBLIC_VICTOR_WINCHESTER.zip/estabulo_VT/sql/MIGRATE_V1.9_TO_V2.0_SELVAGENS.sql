-- estabulo_VT v2.0.0 - Cavalos selvagens
ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `wild_origin` TINYINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `tamed_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `transport_state` VARCHAR(24) NOT NULL DEFAULT 'none',
  ADD COLUMN IF NOT EXISTS `disciplines` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `horseshoe_durability` DECIMAL(6,2) NOT NULL DEFAULT 100;

UPDATE `lrrp_horses`
SET `disciplines`=COALESCE(NULLIF(`disciplines`,''),'{}');
