-- estabulo_VT v2.2.0
ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `temperament` VARCHAR(24) NULL;

-- Cavalos existentes recebem personalidade aleatória no primeiro spawn.
