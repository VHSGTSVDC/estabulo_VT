-- estabulo_VT v1.5.0
-- Reprodução / genética / pedigree.
-- Não apaga cavalos existentes.

ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `sex` VARCHAR(8) NOT NULL DEFAULT 'male',
  ADD COLUMN IF NOT EXISTS `birth_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `father_id` INT NULL,
  ADD COLUMN IF NOT EXISTS `mother_id` INT NULL,
  ADD COLUMN IF NOT EXISTS `genetics` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `breeding_cooldown_until` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `life_stage` VARCHAR(16) NOT NULL DEFAULT 'adult',
  ADD COLUMN IF NOT EXISTS `rarity` VARCHAR(16) NOT NULL DEFAULT 'common',
  ADD COLUMN IF NOT EXISTS `mutation` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `death_state` VARCHAR(16) NOT NULL DEFAULT 'alive';

CREATE TABLE IF NOT EXISTS `lrrp_stable_pregnancies` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL,
  `mother_id` INT NOT NULL,
  `father_id` INT NOT NULL,
  `foal_name` VARCHAR(32) NOT NULL,
  `finish_at` DATETIME NOT NULL,
  `status` VARCHAR(16) NOT NULL DEFAULT 'pregnant',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_preg_owner` (`identifier`,`charidentifier`),
  KEY `idx_preg_status` (`status`,`finish_at`)
);

UPDATE `lrrp_horses`
SET
  `genetics`=COALESCE(NULLIF(`genetics`,''),'{}'),
  `mutation`=COALESCE(NULLIF(`mutation`,''),'{}'),
  `life_stage`=COALESCE(NULLIF(`life_stage`,''),'adult'),
  `rarity`=COALESCE(NULLIF(`rarity`,''),'common'),
  `death_state`=COALESCE(NULLIF(`death_state`,''),'alive');
