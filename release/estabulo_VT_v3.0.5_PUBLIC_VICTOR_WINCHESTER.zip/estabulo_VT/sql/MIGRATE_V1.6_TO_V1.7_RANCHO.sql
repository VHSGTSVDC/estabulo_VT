-- estabulo_VT v1.7.0 - Rancho funcional
ALTER TABLE `lrrp_ranches`
  ADD COLUMN IF NOT EXISTS `feed_stock` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `water_stock` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `last_auto_care` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `next_bill_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `operating_debt` INT NOT NULL DEFAULT 0;

ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `ranch_id` INT NULL;

CREATE TABLE IF NOT EXISTS `lrrp_ranch_workers` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ranch_id` INT NOT NULL,
  `name` VARCHAR(40) NOT NULL,
  `role` VARCHAR(24) NOT NULL DEFAULT 'caretaker',
  `wage` INT NOT NULL DEFAULT 0,
  `status` VARCHAR(16) NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ranch_workers_ranch` (`ranch_id`)
);

UPDATE `lrrp_ranches`
SET `next_bill_at`=DATE_ADD(NOW(),INTERVAL 720 HOUR)
WHERE `next_bill_at` IS NULL;
