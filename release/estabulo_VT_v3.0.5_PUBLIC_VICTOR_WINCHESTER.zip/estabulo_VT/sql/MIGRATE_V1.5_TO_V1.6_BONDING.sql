-- estabulo_VT v1.6.0
-- Normaliza Bonding para níveis 1–4 conforme XP existente.
UPDATE lrrp_horses
SET bonding = CASE
    WHEN COALESCE(xp,0) >= 700 THEN 4
    WHEN COALESCE(xp,0) >= 300 THEN 3
    WHEN COALESCE(xp,0) >= 100 THEN 2
    ELSE 1
END;
