-- LRRP_Stables v0.8 -> v0.9
ALTER TABLE `lrrp_ranches`
  ADD COLUMN IF NOT EXISTS `hay_stock` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `water_stock` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `pasture_capacity` INT NOT NULL DEFAULT 6,
  ADD COLUMN IF NOT EXISTS `zone_config` LONGTEXT NULL;

ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `wild_origin` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `tamed_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `transport_state` VARCHAR(16) NOT NULL DEFAULT 'none';

CREATE TABLE IF NOT EXISTS `lrrp_ranch_structures` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ranch_id` INT NOT NULL,
  `structure_key` VARCHAR(40) NOT NULL,
  `label` VARCHAR(80) NOT NULL,
  `level` INT NOT NULL DEFAULT 1,
  `x` DOUBLE NOT NULL, `y` DOUBLE NOT NULL, `z` DOUBLE NOT NULL, `heading` DOUBLE NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_ranch_structure` (`ranch_id`,`structure_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_ranch_stock_logs` (
  `id` BIGINT NOT NULL AUTO_INCREMENT, `ranch_id` INT NOT NULL, `stock_type` VARCHAR(20) NOT NULL,
  `amount` INT NOT NULL, `reason` VARCHAR(80) NULL, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_ranch_stock` (`ranch_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_horse_transport` (
  `id` INT NOT NULL AUTO_INCREMENT, `ranch_id` INT NOT NULL, `horse_id` INT NOT NULL,
  `identifier` VARCHAR(80) NOT NULL, `charidentifier` INT NOT NULL, `status` VARCHAR(16) NOT NULL DEFAULT 'loaded',
  `loaded_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, `unloaded_at` DATETIME NULL,
  PRIMARY KEY (`id`), KEY `idx_transport_ranch` (`ranch_id`,`status`), KEY `idx_transport_horse` (`horse_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
