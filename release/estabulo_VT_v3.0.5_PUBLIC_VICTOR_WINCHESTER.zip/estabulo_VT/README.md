# LRRP_Stables v1.0.0

Release para RedM + VORP + vorp_inventory, com estábulo, rancho, criação, competições, doma, profissões, permissões, auditoria e ferramentas de produção.


Sistema avançado de estábulos para RedM + VORP + VORP Inventory + oxmysql.

## Recursos principais

- Vários cavalos por personagem (`identifier + charIdentifier`)
- Persistência MySQL de vida, stamina, fome, sede, limpeza, XP, bonding e treino
- Loja, showroom 3D, câmera orbital, acessórios, ferraduras e alforje via VORP Inventory
- Reprodução, gestação real e crescimento em fases
- Genética herdada com raridade e chance de mutação
- Pedigree com pai/mãe e certificado físico no inventário
- Doenças, ferimentos, veterinário e seguro
- Morte permanente configurável, com recuperação quando houver seguro válido
- Profissão de veterinário usando medicamento físico
- Profissão de ferrador usando kit físico
- Rancho próprio com níveis e capacidade
- Mercado direto entre jogadores e leilão com lances
- Corridas time-trial, ranking por pista e campeonato por temporada
- Pagamentos pendentes para vendedores/jogadores offline
- API de estábulo particular para scripts de propriedades

## Dependências

```cfg
ensure oxmysql
ensure vorp_core
ensure vorp_inventory
ensure LRRP_Stables
```

## Instalação nova

Execute:

```text
sql/lrrp_stables.sql
```

## Atualizando da v0.6

Não apague as tabelas existentes. Execute apenas:

```text
sql/migrate_v0.6_to_v0.7.sql
```

## Itens do VORP Inventory usados pela v0.7

Cadastre estes nomes de item no seu `items` do VORP Inventory usando o padrão da sua base:

```text
horse_pedigree   - Certificado de Pedigree
horse_medicine   - Medicamento Veterinário
horseshoe_kit    - Kit de Ferrador
```

Os nomes podem ser alterados em `Config.Pedigree.item` e `Config.ProfessionalItems`.

A API usada pelo script é:

```lua
exports.vorp_inventory:getItem(source, item)
exports.vorp_inventory:subItem(source, item, amount)
exports.vorp_inventory:addItem(source, item, amount, metadata)
```

Se `horse_pedigree` não existir no banco de itens, a taxa de emissão é devolvida e o jogador recebe uma mensagem de configuração.

## Abas da NUI

- Meus cavalos
- Loja
- Cuidados
- Acessórios
- Desempenho
- Criação
- Saúde
- Corridas
- Mercado
- Rancho
- Leilão
- Campeonato

## Gestação e crescimento

Configuração padrão:

```lua
Config.Pregnancy = {
    gestationHours = 24,
    growth = {
        newbornHours = 6,
        foalHours = 24,
        juvenileHours = 48,
        adultHours = 72
    }
}
```

A égua é registrada em `lrrp_stable_pregnancies`. O potro só é criado no MySQL quando `finish_at` chega. Depois passa por:

```text
newborn -> foal -> juvenile -> adult
```

## Genética

Atributos herdáveis:

- velocidade
- aceleração
- resistência
- temperamento

Raridades padrão:

- comum
- incomum
- raro
- lendário

A raridade pode dar bônus e existe chance configurável de mutação positiva ou negativa.

## Rancho

O jogador pode criar um rancho na posição em que está pelo menu. O rancho possui nível e capacidade. Cavalos podem ser vinculados ao rancho.

## Leilão

O jogador informa cavalo, preço inicial, moeda e duração. Lances são cobrados no momento do lance. Quando alguém é superado, o valor anterior entra na fila de pagamentos pendentes. No fim do leilão, o cavalo e a permissão do alforje são transferidos ao vencedor e o vendedor recebe o pagamento.

## Seguro e morte permanente

`Config.Death.permanent = true` habilita morte permanente. Cavalo sem seguro é marcado como `dead`. Cavalo com seguro válido fica `claimable` e pode ser recuperado pagando a franquia.

## Veterinário e ferrador

Comandos profissionais existentes:

```text
/veterinario ID_JOGADOR ID_CAVALO
/ferrador ID_JOGADOR ID_CAVALO NIVEL
```

Na v0.7, esses serviços consomem respectivamente:

```text
horse_medicine
horseshoe_kit
```

## Campeonato

Cada resultado de corrida adiciona pontos na temporada definida em:

```lua
Config.Championship.season
```

Para finalizar a temporada pelo console do servidor:

```text
lrrp_finalizartemporada
```

Os três primeiros recebem premiação pela fila `lrrp_stable_payouts`, inclusive se estiverem offline.

## API de propriedade

Mantida da v0.6:

```lua
exports.LRRP_Stables:RegisterPrivateStable('fazenda_001', {
    identifier = ownerIdentifier,
    charIdentifier = ownerCharId,
    label = 'Estábulo da Fazenda',
    x = -100.0, y = 200.0, z = 90.0, heading = 180.0
})
```

Cliente:

```lua
exports.LRRP_Stables:OpenPrivateStable({ stableIndex = 1 })
```

## Observações

- O showroom usa cavalo local de exposição para evitar criação desnecessária de Network IDs.
- Componentes visuais continuam sujeitos à compatibilidade de cada modelo de cavalo do RDR2.
- Os tempos padrão de gestação/crescimento são curtos para gameplay; ajuste para o ritmo do seu servidor.

## v0.8 — Rancho vivo e corridas multiplayer
A v0.8 adiciona operação automática do rancho, empregados/tratadores, estoque de ração, pasto local, economia periódica, leiloeiro presencial, profissão jockey, salas de corrida multiplayer, apostas, troféus físicos e painel staff.

### Atualização da v0.7
Execute somente:
```sql
sql/migrate_v0.7_to_v0.8.sql
```
Não apague `lrrp_horses` nem as tabelas anteriores.

### Item novo no VORP Inventory
Cadastre `horse_trophy`. O item recebe metadata com pista, posição, cavalo e evento. O item `horsemeal` também é usado para abastecer o estoque do rancho (configurável).

### Permissão staff
No `server.cfg`, conceda o ACE a um grupo já usado pela sua staff:
```cfg
add_ace group.admin lrrp.stables.admin allow
```
A aba **Staff** só libera as ações quando o servidor confirma esse ACE.

### Fluxo das corridas multiplayer
1. Um jogador cria uma sala escolhendo pista e cavalo adulto.
2. Outros jogadores entram com seus cavalos.
3. Antes da largada, qualquer jogador pode apostar em um participante.
4. O host inicia a corrida. Os clientes recebem contagem regressiva simultânea.
5. O servidor valida a chegada, registra a ordem e distribui o pote.
6. Os três primeiros recebem premiação; jockeys podem receber bônus configurado.
7. Apostadores do vencedor dividem o pool líquido de apostas.

### Rancho automático
Tratadores só executam cuidado automático se houver estoque de ração e a folha operacional estiver quitada. A folha vence a cada `Config.RanchAutomation.billingHours` (720 horas por padrão). O proprietário quita a dívida pela aba **Operação do Rancho**.


## v0.9 — Rancho físico e corridas avançadas
Veja `docs/V0.9_INSTALACAO.md`. Novidades: estruturas construíveis, estoque físico de feno/água, transporte de cavalos, cavalos selvagens e doma, ferrador com minigame, checkpoints de corrida, odds e temporada automática.
