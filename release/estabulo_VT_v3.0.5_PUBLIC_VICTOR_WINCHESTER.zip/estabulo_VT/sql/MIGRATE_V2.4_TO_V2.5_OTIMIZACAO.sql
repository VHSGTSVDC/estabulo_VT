-- estabulo_VT v2.5.0 — índices de desempenho
-- Não altera nem apaga dados.

CREATE INDEX IF NOT EXISTS `idx_lrrp_horses_owner_primary`
ON `lrrp_horses` (`identifier`,`charidentifier`,`is_primary`,`id`);

CREATE INDEX IF NOT EXISTS `idx_lrrp_horses_owner_state`
ON `lrrp_horses` (`identifier`,`charidentifier`,`death_state`);

CREATE INDEX IF NOT EXISTS `idx_lrrp_horses_ranch_state`
ON `lrrp_horses` (`ranch_id`,`death_state`,`life_stage`);

CREATE INDEX IF NOT EXISTS `idx_lrrp_horses_critical`
ON `lrrp_horses` (`death_state`,`critical_until`);

CREATE INDEX IF NOT EXISTS `idx_lrrp_pregnancies_status_finish`
ON `lrrp_stable_pregnancies` (`status`,`finish_at`);

CREATE INDEX IF NOT EXISTS `idx_lrrp_market_horse`
ON `lrrp_stable_market` (`horse_id`);
