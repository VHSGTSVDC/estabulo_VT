ALTER TABLE `lrrp_horses` ADD COLUMN IF NOT EXISTS `upgrades` LONGTEXT NULL AFTER `weapon_storage`;
UPDATE `lrrp_horses` SET `upgrades`='{}' WHERE `upgrades` IS NULL OR `upgrades`='';
