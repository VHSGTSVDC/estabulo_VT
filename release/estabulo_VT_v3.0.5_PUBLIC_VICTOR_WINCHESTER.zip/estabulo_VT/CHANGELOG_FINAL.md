# Changelog — v3.0.0 FINAL

- Consolidação da linha v1.x–v2.5.
- SQL final único e idempotente.
- Verificação automática de schema na inicialização.
- Mensagem clara quando coluna/tabela obrigatória estiver faltando.
- Comando `estabulostatus`.
- Mantidas as proteções de rate limit da v2.5.
- Mantida morte segura/estado crítico da v2.4.
- Mantidos ferimentos/recuperação da v2.3.
- Mantido temperamento da v2.2.
- Mantidos comandos de comportamento da v2.1.
- Mantida doma de selvagens da v2.0.
- Nenhum grande sistema novo nesta release para preservar estabilidade.
