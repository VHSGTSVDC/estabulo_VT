# 0.9.0
- Construção física de rancho (cercas, cochos, bebedouros, abrigo e redondel).
- Estoques físicos separados de feno e água.
- Carroça de transporte de cavalos.
- Cavalos selvagens, captura e minigame de doma.
- Veterinário com ação dedicada e ferrador com minigame.
- Corridas multiplayer com checkpoints e odds dinâmicas.
- Temporadas automáticas de 30 dias.
- Painel staff com indicadores econômicos.

# Changelog

## 0.7.0
- Rancho próprio com níveis, capacidade e vínculo de cavalos.
- Gestação persistente por tempo real e nascimento processado no servidor.
- Crescimento: newborn, foal, juvenile e adult.
- Genética herdada com raridade e mutações.
- Certificado físico de pedigree com metadata via VORP Inventory.
- Seguro, sinistro e morte permanente configurável.
- Veterinário passa a consumir `horse_medicine` em serviço profissional.
- Ferrador passa a consumir `horseshoe_kit` em serviço profissional.
- Leilão com duração, lances, reembolso de lance superado e transferência automática.
- Campeonato por temporada com pontos e premiação do pódio.
- Novas abas NUI: Rancho, Leilão e Campeonato.
- Integração com os dados e tabelas existentes da v0.6 preservada.

## 0.6.0
- Reprodução, saúde, corridas, mercado e propriedades.

## 0.8.0
- Rancho vivo: tratadores, estoque de ração, cuidado automático e folha periódica.
- Pasto local com cavalos do rancho soltos sem network ID.
- Corridas multiplayer simultâneas com sala, inscrição, pódio e premiação.
- Apostas persistentes com rateio entre apostadores vencedores.
- Profissão jockey com desconto na inscrição.
- Troféu físico via VORP Inventory.
- Painel staff protegido por ACE `lrrp.stables.admin`.
- Migração `migrate_v0.7_to_v0.8.sql`.

## 1.0.0
- Release de produção e migração incremental da v0.9.
- Permissões de rancho (manager/worker/guest).
- Editor local de estruturas com mover/girar/confirmar/cancelar.
- Disciplinas de treinamento persistentes.
- Diagnóstico veterinário em minigame.
- Desgaste persistente de ferraduras.
- Manutenção/durabilidade das estruturas.
- Auditoria MySQL e webhook opcional.
- Nome visual do cavalo selvagem após a doma.
