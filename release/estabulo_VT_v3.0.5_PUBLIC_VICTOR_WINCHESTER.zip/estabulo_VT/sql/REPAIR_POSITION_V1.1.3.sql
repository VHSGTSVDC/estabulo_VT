-- estabulo_VT v1.1.3
-- Corrige persistência da última posição do cavalo.
-- Não apaga dados existentes.

ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `last_x` DOUBLE NULL,
  ADD COLUMN IF NOT EXISTS `last_y` DOUBLE NULL,
  ADD COLUMN IF NOT EXISTS `last_z` DOUBLE NULL;
