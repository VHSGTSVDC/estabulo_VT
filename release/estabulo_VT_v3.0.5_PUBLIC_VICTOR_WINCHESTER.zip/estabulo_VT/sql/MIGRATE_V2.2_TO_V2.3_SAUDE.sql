-- estabulo_VT v2.3.0
-- O sistema usa a coluna health_state existente em JSON.
ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `health_state` LONGTEXT NULL;

UPDATE `lrrp_horses`
SET `health_state`='{}'
WHERE `health_state` IS NULL OR `health_state`='';
