-- LRRP_Stables v0.9 -> v1.0.0
-- Migração incremental: não remove cavalos nem dados anteriores.

ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `disciplines` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `horseshoe_durability` INT NOT NULL DEFAULT 100;
UPDATE `lrrp_horses` SET `disciplines`='{}' WHERE `disciplines` IS NULL;

ALTER TABLE `lrrp_ranch_structures`
  ADD COLUMN IF NOT EXISTS `durability` INT NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS `max_durability` INT NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS `last_maintained_at` DATETIME NULL;
UPDATE `lrrp_ranch_structures` SET `last_maintained_at`=NOW() WHERE `last_maintained_at` IS NULL;

CREATE TABLE IF NOT EXISTS `lrrp_ranch_members` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ranch_id` INT NOT NULL,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL,
  `player_name` VARCHAR(80) NOT NULL,
  `role` VARCHAR(16) NOT NULL DEFAULT 'worker',
  `status` VARCHAR(16) NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ranch_member` (`ranch_id`,`identifier`,`charidentifier`),
  KEY `idx_ranch_member_owner` (`identifier`,`charidentifier`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_audit_logs` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `source_id` INT NOT NULL DEFAULT 0,
  `player_name` VARCHAR(80) NOT NULL,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL DEFAULT 0,
  `action` VARCHAR(64) NOT NULL,
  `target_type` VARCHAR(32) NULL,
  `target_id` INT NULL,
  `details` LONGTEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_action` (`action`,`created_at`),
  KEY `idx_audit_player` (`identifier`,`charidentifier`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
