CREATE TABLE IF NOT EXISTS `lrrp_horses` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(64) NOT NULL,
  `charidentifier` INT NOT NULL,
  `name` VARCHAR(32) NOT NULL DEFAULT 'Cavalo',
  `model` VARCHAR(80) NOT NULL,
  `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
  `price` INT NOT NULL DEFAULT 0,
  `purchase_currency` TINYINT NOT NULL DEFAULT 0,
  `health` DECIMAL(7,2) NOT NULL DEFAULT 100.00,
  `stamina` DECIMAL(7,2) NOT NULL DEFAULT 100.00,
  `hunger` DECIMAL(7,2) NOT NULL DEFAULT 100.00,
  `thirst` DECIMAL(7,2) NOT NULL DEFAULT 100.00,
  `cleanliness` DECIMAL(7,2) NOT NULL DEFAULT 100.00,
  `xp` INT NOT NULL DEFAULT 0,
  `bonding` TINYINT NOT NULL DEFAULT 0,
  `training` INT NOT NULL DEFAULT 0,
  `accessories` LONGTEXT NULL,
  `weapon_storage` LONGTEXT NULL,
  `upgrades` LONGTEXT NULL,
  `sex` VARCHAR(8) NOT NULL DEFAULT 'male',
  `birth_at` DATETIME NULL,
  `father_id` INT NULL,
  `mother_id` INT NULL,
  `genetics` LONGTEXT NULL,
  `health_state` LONGTEXT NULL,
  `breeding_cooldown_until` DATETIME NULL,
  `life_stage` VARCHAR(12) NOT NULL DEFAULT 'adult',
  `last_x` DECIMAL(12,4) NULL,
  `last_y` DECIMAL(12,4) NULL,
  `last_z` DECIMAL(12,4) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_owner` (`identifier`,`charidentifier`),
  KEY `idx_primary` (`identifier`,`charidentifier`,`is_primary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `lrrp_stable_accessories` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(64) NOT NULL,
  `charidentifier` INT NOT NULL,
  `category` VARCHAR(32) NOT NULL,
  `component_hash` VARCHAR(24) NOT NULL,
  `price_paid` INT NOT NULL DEFAULT 0,
  `currency` TINYINT NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_owned_accessory` (`identifier`,`charidentifier`,`category`,`component_hash`),
  KEY `idx_accessory_owner` (`identifier`,`charidentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `lrrp_stable_market` (
  `id` INT NOT NULL AUTO_INCREMENT, `horse_id` INT NOT NULL, `seller_identifier` VARCHAR(80) NOT NULL, `seller_charidentifier` INT NOT NULL, `price` INT NOT NULL, `currency` TINYINT NOT NULL DEFAULT 0, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), UNIQUE KEY `uq_market_horse` (`horse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS `lrrp_stable_race_results` (
  `id` INT NOT NULL AUTO_INCREMENT, `track_key` VARCHAR(64) NOT NULL, `horse_id` INT NOT NULL, `identifier` VARCHAR(80) NOT NULL, `charidentifier` INT NOT NULL, `time_ms` INT NOT NULL, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `idx_race_track_time` (`track_key`,`time_ms`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS `lrrp_private_stables` (
  `id` INT NOT NULL AUTO_INCREMENT, `property_key` VARCHAR(100) NOT NULL, `owner_identifier` VARCHAR(80) NULL, `owner_charidentifier` INT NULL, `label` VARCHAR(100) NOT NULL, `x` DOUBLE NOT NULL, `y` DOUBLE NOT NULL, `z` DOUBLE NOT NULL, `heading` DOUBLE NOT NULL DEFAULT 0, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), UNIQUE KEY `uq_property_key` (`property_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS `lrrp_stable_payouts` (
  `id` INT NOT NULL AUTO_INCREMENT, `identifier` VARCHAR(80) NOT NULL, `charidentifier` INT NOT NULL, `amount` INT NOT NULL, `currency` TINYINT NOT NULL DEFAULT 0, `reason` VARCHAR(180) NULL, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `idx_payout_owner` (`identifier`,`charidentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- v0.7 schema
ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `rarity` VARCHAR(16) NOT NULL DEFAULT 'common',
  ADD COLUMN IF NOT EXISTS `mutation` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `insurance_until` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `death_state` VARCHAR(16) NOT NULL DEFAULT 'alive',
  ADD COLUMN IF NOT EXISTS `ranch_id` INT NULL;

UPDATE `lrrp_horses` SET `mutation`='{}' WHERE `mutation` IS NULL;

CREATE TABLE IF NOT EXISTS `lrrp_ranches` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL,
  `name` VARCHAR(80) NOT NULL,
  `level` INT NOT NULL DEFAULT 1,
  `capacity` INT NOT NULL DEFAULT 10,
  `x` DOUBLE NOT NULL, `y` DOUBLE NOT NULL, `z` DOUBLE NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_ranch_owner` (`identifier`,`charidentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_pregnancies` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL,
  `mother_id` INT NOT NULL,
  `father_id` INT NOT NULL,
  `foal_name` VARCHAR(32) NOT NULL,
  `started_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `finish_at` DATETIME NOT NULL,
  `status` VARCHAR(16) NOT NULL DEFAULT 'pregnant',
  PRIMARY KEY (`id`), KEY `idx_preg_due` (`status`,`finish_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_auctions` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `horse_id` INT NOT NULL,
  `seller_identifier` VARCHAR(80) NOT NULL,
  `seller_charidentifier` INT NOT NULL,
  `start_price` INT NOT NULL,
  `currency` TINYINT NOT NULL DEFAULT 0,
  `current_bid` INT NOT NULL DEFAULT 0,
  `bidder_identifier` VARCHAR(80) NULL,
  `bidder_charidentifier` INT NULL,
  `ends_at` DATETIME NOT NULL,
  `status` VARCHAR(16) NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_auction_horse_status` (`horse_id`,`status`), KEY `idx_auction_due` (`status`,`ends_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_championship_points` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `season` VARCHAR(64) NOT NULL,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL,
  `horse_id` INT NOT NULL,
  `points` INT NOT NULL DEFAULT 0,
  `wins` INT NOT NULL DEFAULT 0,
  `races` INT NOT NULL DEFAULT 0,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_season_horse` (`season`,`horse_id`), KEY `idx_champ_rank` (`season`,`points`,`wins`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_seasons` (
  `season` VARCHAR(64) NOT NULL,
  `finalized_at` DATETIME NULL,
  PRIMARY KEY (`season`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- LRRP_Stables v0.7 -> v0.8
ALTER TABLE `lrrp_ranches`
  ADD COLUMN IF NOT EXISTS `feed_stock` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `last_auto_care` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `next_bill_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `operating_debt` INT NOT NULL DEFAULT 0;
UPDATE `lrrp_ranches` SET `next_bill_at`=DATE_ADD(NOW(),INTERVAL 720 HOUR) WHERE `next_bill_at` IS NULL;

CREATE TABLE IF NOT EXISTS `lrrp_ranch_workers` (
  `id` INT NOT NULL AUTO_INCREMENT, `ranch_id` INT NOT NULL, `name` VARCHAR(40) NOT NULL,
  `role` VARCHAR(24) NOT NULL DEFAULT 'caretaker', `wage` INT NOT NULL DEFAULT 180,
  `status` VARCHAR(16) NOT NULL DEFAULT 'active', `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_worker_ranch` (`ranch_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_race_events` (
  `id` INT NOT NULL AUTO_INCREMENT, `track_key` VARCHAR(64) NOT NULL,
  `host_identifier` VARCHAR(80) NOT NULL, `host_charidentifier` INT NOT NULL,
  `status` VARCHAR(16) NOT NULL DEFAULT 'open', `entry_fee` INT NOT NULL DEFAULT 0,
  `currency` TINYINT NOT NULL DEFAULT 0, `pot` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, `started_at` DATETIME NULL, `finished_at` DATETIME NULL,
  PRIMARY KEY (`id`), KEY `idx_race_event_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_race_entries` (
  `id` INT NOT NULL AUTO_INCREMENT, `event_id` INT NOT NULL, `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL, `horse_id` INT NOT NULL, `horse_name` VARCHAR(32) NOT NULL,
  `finish_ms` INT NULL, `position` INT NULL, `status` VARCHAR(16) NOT NULL DEFAULT 'joined',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, `is_jockey` TINYINT(1) NOT NULL DEFAULT 0, PRIMARY KEY (`id`),
  UNIQUE KEY `uq_race_character` (`event_id`,`identifier`,`charidentifier`), KEY `idx_race_entries` (`event_id`,`status`,`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_race_bets` (
  `id` INT NOT NULL AUTO_INCREMENT, `event_id` INT NOT NULL, `entry_id` INT NOT NULL,
  `identifier` VARCHAR(80) NOT NULL, `charidentifier` INT NOT NULL, `amount` INT NOT NULL,
  `currency` TINYINT NOT NULL DEFAULT 0, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_race_bets` (`event_id`,`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- LRRP_Stables v0.8 -> v0.9
ALTER TABLE `lrrp_ranches`
  ADD COLUMN IF NOT EXISTS `hay_stock` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `water_stock` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `pasture_capacity` INT NOT NULL DEFAULT 6,
  ADD COLUMN IF NOT EXISTS `zone_config` LONGTEXT NULL;

ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `wild_origin` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `tamed_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `transport_state` VARCHAR(16) NOT NULL DEFAULT 'none';

CREATE TABLE IF NOT EXISTS `lrrp_ranch_structures` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ranch_id` INT NOT NULL,
  `structure_key` VARCHAR(40) NOT NULL,
  `label` VARCHAR(80) NOT NULL,
  `level` INT NOT NULL DEFAULT 1,
  `x` DOUBLE NOT NULL, `y` DOUBLE NOT NULL, `z` DOUBLE NOT NULL, `heading` DOUBLE NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_ranch_structure` (`ranch_id`,`structure_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_ranch_stock_logs` (
  `id` BIGINT NOT NULL AUTO_INCREMENT, `ranch_id` INT NOT NULL, `stock_type` VARCHAR(20) NOT NULL,
  `amount` INT NOT NULL, `reason` VARCHAR(80) NULL, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_ranch_stock` (`ranch_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_horse_transport` (
  `id` INT NOT NULL AUTO_INCREMENT, `ranch_id` INT NOT NULL, `horse_id` INT NOT NULL,
  `identifier` VARCHAR(80) NOT NULL, `charidentifier` INT NOT NULL, `status` VARCHAR(16) NOT NULL DEFAULT 'loaded',
  `loaded_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, `unloaded_at` DATETIME NULL,
  PRIMARY KEY (`id`), KEY `idx_transport_ranch` (`ranch_id`,`status`), KEY `idx_transport_horse` (`horse_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- LRRP_Stables v0.9 -> v1.0.0
-- Migração incremental: não remove cavalos nem dados anteriores.

ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `disciplines` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `horseshoe_durability` INT NOT NULL DEFAULT 100;
UPDATE `lrrp_horses` SET `disciplines`='{}' WHERE `disciplines` IS NULL;

ALTER TABLE `lrrp_ranch_structures`
  ADD COLUMN IF NOT EXISTS `durability` INT NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS `max_durability` INT NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS `last_maintained_at` DATETIME NULL;
UPDATE `lrrp_ranch_structures` SET `last_maintained_at`=NOW() WHERE `last_maintained_at` IS NULL;

CREATE TABLE IF NOT EXISTS `lrrp_ranch_members` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `ranch_id` INT NOT NULL,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL,
  `player_name` VARCHAR(80) NOT NULL,
  `role` VARCHAR(16) NOT NULL DEFAULT 'worker',
  `status` VARCHAR(16) NOT NULL DEFAULT 'active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ranch_member` (`ranch_id`,`identifier`,`charidentifier`),
  KEY `idx_ranch_member_owner` (`identifier`,`charidentifier`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_audit_logs` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `source_id` INT NOT NULL DEFAULT 0,
  `player_name` VARCHAR(80) NOT NULL,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL DEFAULT 0,
  `action` VARCHAR(64) NOT NULL,
  `target_type` VARCHAR(32) NULL,
  `target_id` INT NULL,
  `details` LONGTEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_action` (`action`,`created_at`),
  KEY `idx_audit_player` (`identifier`,`charidentifier`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
