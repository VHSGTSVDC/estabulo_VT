
-- ============================================================
-- estabulo_VT v1.1.0 - REPARO COMPLETO DA TABELA lrrp_horses
-- Não apaga cavalos existentes.
-- Pode ser executado mais de uma vez.
-- ============================================================

ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `identifier` VARCHAR(80) NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS `charidentifier` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `name` VARCHAR(64) NOT NULL DEFAULT 'Cavalo',
  ADD COLUMN IF NOT EXISTS `model` VARCHAR(100) NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS `is_primary` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  ADD COLUMN IF NOT EXISTS `purchase_currency` TINYINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `health` FLOAT NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS `stamina` FLOAT NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS `hunger` FLOAT NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS `thirst` FLOAT NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS `cleanliness` FLOAT NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS `xp` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `bonding` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `training` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `accessories` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `weapon_storage` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `sex` VARCHAR(8) NOT NULL DEFAULT 'male',
  ADD COLUMN IF NOT EXISTS `birth_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `father_id` INT NULL,
  ADD COLUMN IF NOT EXISTS `mother_id` INT NULL,
  ADD COLUMN IF NOT EXISTS `genetics` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `health_state` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `breeding_cooldown_until` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `life_stage` VARCHAR(16) NOT NULL DEFAULT 'adult',
  ADD COLUMN IF NOT EXISTS `rarity` VARCHAR(16) NOT NULL DEFAULT 'common',
  ADD COLUMN IF NOT EXISTS `mutation` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `insurance_until` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `death_state` VARCHAR(16) NOT NULL DEFAULT 'alive',
  ADD COLUMN IF NOT EXISTS `ranch_id` INT NULL,
  ADD COLUMN IF NOT EXISTS `wild_origin` TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `tamed_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `transport_state` VARCHAR(16) NOT NULL DEFAULT 'none',
  ADD COLUMN IF NOT EXISTS `disciplines` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `horseshoe_durability` INT NOT NULL DEFAULT 100,
  ADD COLUMN IF NOT EXISTS `upgrades` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ADD COLUMN IF NOT EXISTS `last_x` DOUBLE NULL,
  ADD COLUMN IF NOT EXISTS `last_y` DOUBLE NULL,
  ADD COLUMN IF NOT EXISTS `last_z` DOUBLE NULL,
  ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

UPDATE `lrrp_horses`
SET
  `accessories` = COALESCE(NULLIF(`accessories`, ''), '{}'),
  `weapon_storage` = COALESCE(NULLIF(`weapon_storage`, ''), '{}'),
  `genetics` = COALESCE(NULLIF(`genetics`, ''), '{}'),
  `health_state` = COALESCE(NULLIF(`health_state`, ''), '{}'),
  `mutation` = COALESCE(NULLIF(`mutation`, ''), '{}'),
  `disciplines` = COALESCE(NULLIF(`disciplines`, ''), '{}'),
  `upgrades` = COALESCE(NULLIF(`upgrades`, ''), '{}'),
  `life_stage` = COALESCE(NULLIF(`life_stage`, ''), 'adult'),
  `death_state` = COALESCE(NULLIF(`death_state`, ''), 'alive'),
  `transport_state` = COALESCE(NULLIF(`transport_state`, ''), 'none');

-- Garante que exista no máximo um cavalo principal por personagem
-- sem apagar registros.
UPDATE `lrrp_horses` h
JOIN (
    SELECT identifier, charidentifier, MIN(id) AS keep_id
    FROM `lrrp_horses`
    WHERE is_primary = 1
    GROUP BY identifier, charidentifier
    HAVING COUNT(*) > 1
) x
  ON h.identifier = x.identifier
 AND h.charidentifier = x.charidentifier
SET h.is_primary = CASE WHEN h.id = x.keep_id THEN 1 ELSE 0 END
WHERE h.is_primary = 1;

-- Índices úteis; ignorar se já existirem não é suportado por todas as versões,
-- por isso ficam comentados por padrão.
-- CREATE INDEX idx_lrrp_horses_owner ON lrrp_horses(identifier, charidentifier);
-- CREATE INDEX idx_lrrp_horses_primary ON lrrp_horses(identifier, charidentifier, is_primary);
