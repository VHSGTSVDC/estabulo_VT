ALTER TABLE `lrrp_horses`
  ADD COLUMN IF NOT EXISTS `sex` VARCHAR(8) NOT NULL DEFAULT 'male',
  ADD COLUMN IF NOT EXISTS `birth_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `father_id` INT NULL,
  ADD COLUMN IF NOT EXISTS `mother_id` INT NULL,
  ADD COLUMN IF NOT EXISTS `genetics` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `health_state` LONGTEXT NULL,
  ADD COLUMN IF NOT EXISTS `breeding_cooldown_until` DATETIME NULL;

CREATE TABLE IF NOT EXISTS `lrrp_stable_market` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `horse_id` INT NOT NULL,
  `seller_identifier` VARCHAR(80) NOT NULL,
  `seller_charidentifier` INT NOT NULL,
  `price` INT NOT NULL,
  `currency` TINYINT NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_market_horse` (`horse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_race_results` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `track_key` VARCHAR(64) NOT NULL,
  `horse_id` INT NOT NULL,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL,
  `time_ms` INT NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_race_track_time` (`track_key`,`time_ms`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_private_stables` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `property_key` VARCHAR(100) NOT NULL,
  `owner_identifier` VARCHAR(80) NULL,
  `owner_charidentifier` INT NULL,
  `label` VARCHAR(100) NOT NULL,
  `x` DOUBLE NOT NULL, `y` DOUBLE NOT NULL, `z` DOUBLE NOT NULL, `heading` DOUBLE NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_property_key` (`property_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

UPDATE `lrrp_horses` SET `genetics`='{}' WHERE `genetics` IS NULL;
UPDATE `lrrp_horses` SET `health_state`='{}' WHERE `health_state` IS NULL;
ALTER TABLE `lrrp_horses` ADD COLUMN IF NOT EXISTS `life_stage` VARCHAR(12) NOT NULL DEFAULT 'adult';

CREATE TABLE IF NOT EXISTS `lrrp_stable_payouts` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL,
  `amount` INT NOT NULL,
  `currency` TINYINT NOT NULL DEFAULT 0,
  `reason` VARCHAR(180) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_payout_owner` (`identifier`,`charidentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
