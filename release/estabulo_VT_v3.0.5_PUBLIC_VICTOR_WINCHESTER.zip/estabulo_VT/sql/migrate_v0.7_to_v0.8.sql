-- LRRP_Stables v0.7 -> v0.8
ALTER TABLE `lrrp_ranches`
  ADD COLUMN IF NOT EXISTS `feed_stock` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `last_auto_care` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `next_bill_at` DATETIME NULL,
  ADD COLUMN IF NOT EXISTS `operating_debt` INT NOT NULL DEFAULT 0;
UPDATE `lrrp_ranches` SET `next_bill_at`=DATE_ADD(NOW(),INTERVAL 720 HOUR) WHERE `next_bill_at` IS NULL;

CREATE TABLE IF NOT EXISTS `lrrp_ranch_workers` (
  `id` INT NOT NULL AUTO_INCREMENT, `ranch_id` INT NOT NULL, `name` VARCHAR(40) NOT NULL,
  `role` VARCHAR(24) NOT NULL DEFAULT 'caretaker', `wage` INT NOT NULL DEFAULT 180,
  `status` VARCHAR(16) NOT NULL DEFAULT 'active', `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_worker_ranch` (`ranch_id`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_race_events` (
  `id` INT NOT NULL AUTO_INCREMENT, `track_key` VARCHAR(64) NOT NULL,
  `host_identifier` VARCHAR(80) NOT NULL, `host_charidentifier` INT NOT NULL,
  `status` VARCHAR(16) NOT NULL DEFAULT 'open', `entry_fee` INT NOT NULL DEFAULT 0,
  `currency` TINYINT NOT NULL DEFAULT 0, `pot` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, `started_at` DATETIME NULL, `finished_at` DATETIME NULL,
  PRIMARY KEY (`id`), KEY `idx_race_event_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_race_entries` (
  `id` INT NOT NULL AUTO_INCREMENT, `event_id` INT NOT NULL, `identifier` VARCHAR(80) NOT NULL,
  `charidentifier` INT NOT NULL, `horse_id` INT NOT NULL, `horse_name` VARCHAR(32) NOT NULL,
  `finish_ms` INT NULL, `position` INT NULL, `status` VARCHAR(16) NOT NULL DEFAULT 'joined',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, `is_jockey` TINYINT(1) NOT NULL DEFAULT 0, PRIMARY KEY (`id`),
  UNIQUE KEY `uq_race_character` (`event_id`,`identifier`,`charidentifier`), KEY `idx_race_entries` (`event_id`,`status`,`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lrrp_stable_race_bets` (
  `id` INT NOT NULL AUTO_INCREMENT, `event_id` INT NOT NULL, `entry_id` INT NOT NULL,
  `identifier` VARCHAR(80) NOT NULL, `charidentifier` INT NOT NULL, `amount` INT NOT NULL,
  `currency` TINYINT NOT NULL DEFAULT 0, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_race_bets` (`event_id`,`entry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
